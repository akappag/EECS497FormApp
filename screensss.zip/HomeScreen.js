import React from 'react';
import Amplify from 'aws-amplify';
import {createStackNavigator, createAppContainer} from 'react-navigation';
import { StyleSheet, Text, View, TouchableOpacity, Image, ImageBackground } from 'react-native';
import { Button } from 'react-native-elements';
import { Input } from 'react-native-elements';
import Auth from '@aws-amplify/auth'

export default class HomeScreen extends React.Component {
  state = {
    name: '',
    length: 0,
    width: 0,
  }

  onChangeText(key, value) {
    this.setState({[key]: value})
  }

  onNewFormation = async () => {
    this.props.navigation.navigate('NewFormation')
  }

  onSignOut = async () => {
    Auth.currentAuthenticatedUser()
    .then(user => {
      console.log(user);

      this.props.navigation.navigate('SignOut', {userCP: user})
      });
  }

  render() {
    return (
      <View style={styles.container}>
        <ImageBackground style={styles.backgroundImg} source={require('../../images/wilderness.jpg')} ></ImageBackground>
        <View style={styles.newOverlay}>
          <Image style={styles.imgStyle} source={require('../../images/logo.png')} />
          <TouchableOpacity
           style={
             [styles.buttonStyle,
               {
                 flexDirection: 'row',
                 justifyContent: 'center',
                 marginBottom: 30
               }
             ]
           }
           onPress={this.onNewFormation}>
           <Text style={styles.buttonText}>
             New Formation
           </Text>
         </TouchableOpacity>
         <TouchableOpacity
          style={
            [styles.buttonStyle,
              {
                flexDirection: 'row',
                justifyContent: 'center',
                marginBottom: 30
              }
            ]
          }
          onPress={this.onNewFormation}>
          <Text style={styles.buttonText}>
            List of Formations
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
         style={
           [styles.buttonStyle,
             {
               flexDirection: 'row',
               justifyContent: 'center',
               marginBottom: 30
             }
           ]
         }
         onPress={this.onSignOut}>
         <Text style={styles.buttonText}>
           Profile Settings
         </Text>
       </TouchableOpacity>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  imgStyle: {
    marginTop: 25,
    height: 150,
    width: 200,
    position: 'relative',
    bottom: 100
  },
  backgroundImg: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    bottom: 0,
    height: 800,
    width: 600,
  },
  newOverlay: {
    flex: 1,
    height: 800,
    width: 400,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,.3)'
  },
  input: {
    flex: 1,
    fontSize: 17,
    fontWeight: 'bold',
    color: '#5a52a5',
  },
  container: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonStyle: {
    alignItems: 'center',
    backgroundColor: '#53BBBD',
    padding: 14,
    marginBottom: 20,
    borderRadius: 24,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: "#fff",
  },
});
