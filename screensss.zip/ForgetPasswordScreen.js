import React from 'react'
import {
  TouchableOpacity,
  TouchableWithoutFeedback,
  StyleSheet,
  Text,
  SafeAreaView,
  StatusBar,
  KeyboardAvoidingView,
  Keyboard,
  View,
  Alert,
  Animated,
  Image,
  ImageBackground,
  ScrollView
} from 'react-native'
import {
  Container,
  Item,
  Input,
  Icon
} from 'native-base'
import Auth from '@aws-amplify/auth'

export default class ForgetPasswordScreen extends React.Component {
  state = {
    username: '',
    authCode: '',
    newPassword: '',
  }
  onChangeText(key, value) {
    this.setState({[key]: value})
  }

  // Request a new password
  async forgotPassword() {
    const { username } = this.state
    await Auth.forgotPassword(username)
    .then(data => console.log('New code sent', data))
    .catch(err => {
      if (! err.message) {
        console.log('Error while setting up the new password: ', err)
        Alert.alert('Error while setting up the new password: ', err)
      } else {
        console.log('Error while setting up the new password: ', err.message)
        Alert.alert('Error while setting up the new password: ', err.message)
      }
    })
  }

  // Upon confirmation redirect the user to the Sign In page
  async forgotPasswordSubmit() {
    const { username, authCode, newPassword } = this.state
    await Auth.forgotPasswordSubmit(username, authCode, newPassword)
    .then(() => {
      this.props.navigation.navigate('SignIn')
      console.log('the New password submitted successfully')
    })
    .catch(err => {
      if (! err.message) {
        console.log('Error while confirming the new password: ', err)
        Alert.alert('Error while confirming the new password: ', err)
      } else {
        console.log('Error while confirming the new password: ', err.message)
        Alert.alert('Error while confirming the new password: ', err.message)
      }
    })
  }

  render() {
   return (
     <SafeAreaView style={styles.container}>
       <StatusBar/>
       <KeyboardAvoidingView
         style={styles.container}
         behavior='padding'
         enabled
         keyboardVerticalOffset={23}>
         <ScrollView>
           <ImageBackground style={styles.backgroundImg} source={require('../../images/wilderness.jpg')} ></ImageBackground>
           <View style={styles.newOverlay} >
             <TouchableWithoutFeedback style={styles.container} onPress={Keyboard.dismiss}>
               <View style={styles.container}>
                 {/* Infos */}
                 <Container style={styles.infoContainer}>
                   <View style={styles.container}>
                     {/* Username */}
                     <Item rounded style={styles.itemStyle}>
                       <Icon
                         active
                         name='person'
                         style={styles.iconStyle}
                       />
                       <Input
                         style={styles.input}
                         placeholder='Username'
                         placeholderTextColor='#adb4bc'
                         keyboardType={'email-address'}
                         returnKeyType='go'
                         autoCapitalize='none'
                         autoCorrect={false}
                         onChangeText={value => this.onChangeText('username', value)}
                       />
                     </Item>
                     <TouchableOpacity
                       style={styles.buttonStyle}
                       onPress={() => this.forgotPassword()}>
                       <Text style={styles.buttonText}>
                         Send Code
                       </Text>
                     </TouchableOpacity>
                     {/* the New password section  */}
                     <Item rounded style={styles.itemStyle}>
                       <Icon
                         active
                         name='lock'
                         style={styles.iconStyle}
                       />
                       <Input
                         style={styles.input}
                         placeholder='New password'
                         placeholderTextColor='#adb4bc'
                         returnKeyType='next'
                         autoCapitalize='none'
                         autoCorrect={false}
                         secureTextEntry={true}
                         onSubmitEditing={(event) => { this.refs.SecondInput._root.focus()}}
                         onChangeText={value => this.onChangeText('newPassword', value)}
                       />
                     </Item>
                     {/* Code confirmation section  */}
                     <Item rounded style={styles.itemStyle}>
                       <Icon
                         active
                         name='md-apps'
                         style={styles.iconStyle}
                       />
                       <Input
                         style={styles.input}
                         placeholder='Confirmation code'
                         placeholderTextColor='#adb4bc'
                         keyboardType={'numeric'}
                         returnKeyType='done'
                         autoCapitalize='none'
                         autoCorrect={false}
                         secureTextEntry={false}
                         ref='SecondInput'
                         onChangeText={value => this.onChangeText('authCode', value)}
                       />
                     </Item>
                     <TouchableOpacity
                       style={styles.buttonStyle}
                       onPress={() => this.forgotPasswordSubmit()}>
                       <Text style={styles.buttonText}>
                         Confirm the new password
                       </Text>
                     </TouchableOpacity>
                   </View>
                 </Container>
               </View>
             </TouchableWithoutFeedback>
           </View>
         </ScrollView>
       </KeyboardAvoidingView>
     </SafeAreaView>
   );
 }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    flexDirection: 'column'
  },
  backgroundImg: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    bottom: 0,
    height: 800,
    width: 600,
  },
  newOverlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,.3)'
  },
  input: {
    flex: 1,
    fontSize: 17,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },
  infoContainer: {
    height: 800,
    width: 400,
    bottom: 25,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 30,
    backgroundColor: 'transparent',
  },
  itemStyle: {
    marginBottom: 20,
  },
  iconStyle: {
    color: '#FFFFFF',
    fontSize: 28,
    marginLeft: 15
  },
  buttonStyle: {
    alignItems: 'center',
    backgroundColor: '#53BBBD',
    padding: 14,
    marginBottom: 20,
    borderRadius: 24,
  },
  buttonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: "#fff",
  },
  logoContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 400,
    bottom: 180,
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
})
